	STONECUTTER CUTS WOOD... couse why not?
	by IIWadid1196II


	|| EN ||
	
	What is it?:
	------------

	- It's simple data pack that allows you to make for example wooden stairs from planks just like 
	cobbelstone stairs from cobbelstone in stone sutter. That's 60 new recipes.

	
	How to install it?:
	-------------------

	- Open your save folder and find "datapacks" folder. Put downlanded zip file here.



	|| PL ||

	Co to jest?:
	------------

	- Jest to prosty data pack, kt�ry umo�liwi Ci wytworzenie np. drewnianych schod�w z desek tak jak 
	brukowe schody z� bruku w przecinarce.
Razem 60 nowych receptur.

	
	Jak go zainstalowa�?:
	---------------------

	- Otw�rz folder swojgo zapisu, nast�pnie znajd� folder datapacks. Umie�� w nim pobrany plik zip.